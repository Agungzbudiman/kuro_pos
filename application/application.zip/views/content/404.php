<header class="masthead bg-primary text-white text-center" style="padding-top: 120px">
    <div class="container d-flex align-items-center flex-column">
        <!-- Masthead Avatar Image--><img class="masthead-avatar mb-5" src="../assets/template/assets/img/page-not-found.png" alt="" /><!-- Masthead Heading-->
        <h1 class="masthead-heading text-uppercase mb-0">404! Not Found</h1>
        <!-- Icon Divider-->
        <div class="divider-custom divider-light">
            <div class="divider-custom-line"></div>
            <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
            <div class="divider-custom-line"></div>
        </div>
        <!-- Masthead Subheading-->
    </div>
</header>