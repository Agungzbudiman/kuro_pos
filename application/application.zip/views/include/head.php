
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<meta name="description" content="" />
<meta name="author" content="" />
<title>Freelancer - Start Bootstrap Theme</title>
<!-- Font Awesome icons (free version)-->
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/') ?>fontawesome/css/all.css">
<!-- Google fonts-->
<link href="<?= base_url('assets/template/') ?>css/Montserrat.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url('assets/template/') ?>css/Lato.css" rel="stylesheet" type="text/css" />
<!-- Core theme CSS (includes Bootstrap)-->
<link href="<?= base_url('assets/template/') ?>css/styles.css" rel="stylesheet" />
<link href="<?= base_url('assets/template/') ?>css/costum.css" rel="stylesheet" />